package ua.meekeyn.requiemunofficial.mixin;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ProjectileWeaponItem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ua.meekeyn.requiemunofficial.common.possession.PossessionProjectileHooks;
import ua.meekeyn.requiemunofficial.common.soul.SoulManager;
import ua.meekeyn.requiemunofficial.common.util.ModTags;

import java.util.UUID;

@Mixin(Player.class)
public abstract class PlayerMixin {
    @Inject(method = "getProjectile", at = @At("RETURN"), cancellable = true)
    private void requiemunofficial$generatePossessedBodyArrow(ItemStack weapon,
                                                              CallbackInfoReturnable<ItemStack> cir) {
        if (!cir.getReturnValue().isEmpty()) {
            return;
        }

        Player player = (Player) (Object) this;
        LivingEntity host = requiemunofficial$getPossessedHost(player);
        if (host != null && host.getType().is(ModTags.ARROW_GENERATORS)) {
            if (weapon.getItem() instanceof ProjectileWeaponItem) {
                weapon.getOrCreateTag().putBoolean(PossessionProjectileHooks.INFINITY_SHOT_TAG, true);
            }
            cir.setReturnValue(new ItemStack(Items.ARROW));
        }
    }

    private static LivingEntity requiemunofficial$getPossessedHost(Player player) {
        UUID hostId = SoulManager.getPossessedEntityId(player);
        if (hostId == null) {
            return null;
        }

        for (Entity entity : player.level().getEntities(
                player,
                player.getBoundingBox().inflate(128.0D),
                entity -> hostId.equals(entity.getUUID())
        )) {
            if (entity instanceof LivingEntity living && living.isAlive()) {
                return living;
            }
        }
        return null;
    }
}
