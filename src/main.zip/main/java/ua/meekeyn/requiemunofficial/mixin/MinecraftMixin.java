package ua.meekeyn.requiemunofficial.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.DeathScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.protocol.game.ServerboundClientCommandPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ua.meekeyn.requiemunofficial.common.soul.SoulManager;
import ua.meekeyn.requiemunofficial.common.soul.SoulState;

@Mixin(Minecraft.class)
public abstract class MinecraftMixin {

    @Inject(method = "setScreen", at = @At("HEAD"), cancellable = true)
    private void requiemunofficial$skipDemonDeathScreen(Screen screen, CallbackInfo ci) {
        Minecraft minecraft = Minecraft.getInstance();
        if (!(screen instanceof DeathScreen)
                || minecraft.player == null
                || minecraft.player.connection == null
                || !shouldSkipDeathScreen(SoulManager.getState(minecraft.player))) {
            return;
        }

        minecraft.player.connection.send(new ServerboundClientCommandPacket(
                ServerboundClientCommandPacket.Action.PERFORM_RESPAWN
        ));
        ci.cancel();
    }

    private static boolean shouldSkipDeathScreen(SoulState state) {
        return state == SoulState.REMNANT || state == SoulState.VAGRANT;
    }
}
