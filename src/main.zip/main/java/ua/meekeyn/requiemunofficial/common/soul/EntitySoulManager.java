package ua.meekeyn.requiemunofficial.common.soul;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraftforge.event.entity.EntityLeaveLevelEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import ua.meekeyn.requiemunofficial.RequiemUnofficial;
import ua.meekeyn.requiemunofficial.common.entity.PlayerShellEntity;
import ua.meekeyn.requiemunofficial.common.record.BodyRecordData;
import ua.meekeyn.requiemunofficial.common.util.ModTags;

import java.util.UUID;

@Mod.EventBusSubscriber(modid = RequiemUnofficial.MODID)
public final class EntitySoulManager {
    private static final String HAS_SOUL = "RequiemHasSoul";
    private static final String SOUL_INITIALIZED = "RequiemSoulInitialized";
    private static final String ORIGINAL_NO_AI = "RequiemSoulOriginalNoAi";
    private static final String INERT_APPLIED = "RequiemSoulInertApplied";
    private static final String POSSESSED = "RequiemPossessed";

    private EntitySoulManager() {
    }

    public static boolean hasSoul(LivingEntity entity) {
        if (isNaturallySoulless(entity)) {
            return false;
        }
        if (!entity.getPersistentData().getBoolean(SOUL_INITIALIZED)) {
            entity.getPersistentData().putBoolean(SOUL_INITIALIZED, true);
            entity.getPersistentData().putBoolean(HAS_SOUL, true);
        }
        return entity.getPersistentData().getBoolean(HAS_SOUL);
    }

    public static void removeSoul(LivingEntity entity) {
        entity.getPersistentData().putBoolean(SOUL_INITIALIZED, true);
        entity.getPersistentData().putBoolean(HAS_SOUL, false);
        if (!entity.level().isClientSide()) {
            BodyRecordData.get(entity.level()).getOrCreateRecord(entity);
        }
        immobilizeSoullessBody(entity);
    }

    public static void restoreSoul(LivingEntity entity) {
        if (isNaturallySoulless(entity)) {
            return;
        }
        entity.getPersistentData().putBoolean(SOUL_INITIALIZED, true);
        entity.getPersistentData().putBoolean(HAS_SOUL, true);
        if (entity instanceof Mob mob && entity.getPersistentData().contains(ORIGINAL_NO_AI)) {
            mob.setNoAi(entity.getPersistentData().getBoolean(ORIGINAL_NO_AI));
            entity.getPersistentData().remove(ORIGINAL_NO_AI);
        }
        entity.getPersistentData().remove(INERT_APPLIED);
    }

    public static boolean canBePossessionHost(LivingEntity entity) {
        return isNaturallySoulless(entity) || !hasSoul(entity);
    }

    public static boolean isInertSoullessBody(LivingEntity entity) {
        return !isNaturallySoulless(entity)
                && entity.getPersistentData().getBoolean(SOUL_INITIALIZED)
                && !entity.getPersistentData().getBoolean(HAS_SOUL);
    }

    @SubscribeEvent
    public static void onLivingTick(LivingEvent.LivingTickEvent event) {
        if (event.getEntity().level().isClientSide()) {
            return;
        }
        if (BodyRecordData.getEntityRecordId(event.getEntity()) != null) {
            BodyRecordData.get(event.getEntity().level()).updateRecord(event.getEntity());
        }
        freezeIfInert(event.getEntity());
    }

    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        if (event.getEntity().level().isClientSide()) {
            return;
        }
        UUID recordId = BodyRecordData.getEntityRecordId(event.getEntity());
        if (recordId != null) {
            BodyRecordData.get(event.getEntity().level()).invalidate(recordId);
        }
    }

    @SubscribeEvent
    public static void onEntityLeaveLevel(EntityLeaveLevelEvent event) {
        if (event.getLevel().isClientSide() || !(event.getEntity() instanceof LivingEntity living)) {
            return;
        }
        UUID recordId = BodyRecordData.getEntityRecordId(living);
        if (recordId != null && living.isRemoved()) {
            BodyRecordData.get(event.getLevel()).invalidate(recordId);
        }
    }

    @SubscribeEvent
    public static void onLivingAttack(LivingAttackEvent event) {
        Entity attacker = event.getSource().getEntity();
        if (isInertSoullessBody(event.getEntity()) && attacker != null) {
            pushInertBodyFromAttacker(event.getEntity(), attacker);
        }
        if (attacker instanceof LivingEntity living && isInertSoullessBody(living)) {
            event.setCanceled(true);
        }
    }

    private static void freezeIfInert(LivingEntity entity) {
        if (!isInertSoullessBody(entity)
                || entity.getPersistentData().getBoolean(POSSESSED)
                || entity.getPersistentData().getBoolean(INERT_APPLIED)) {
            return;
        }
        immobilizeSoullessBody(entity);
    }

    private static boolean isNaturallySoulless(LivingEntity entity) {
        return entity instanceof PlayerShellEntity || entity.getType().is(ModTags.SOULLESS);
    }

    private static void immobilizeSoullessBody(LivingEntity entity) {
        if (entity.getPersistentData().getBoolean(POSSESSED)) {
            return;
        }
        entity.getPersistentData().putBoolean(INERT_APPLIED, true);
        entity.setSprinting(false);
        entity.setJumping(false);
        if (entity instanceof Mob mob) {
            if (!entity.getPersistentData().contains(ORIGINAL_NO_AI)) {
                entity.getPersistentData().putBoolean(ORIGINAL_NO_AI, mob.isNoAi());
            }
            mob.setTarget(null);
            mob.getNavigation().stop();
            mob.setNoAi(true);
        }
    }

    private static void pushInertBodyFromAttacker(LivingEntity body, Entity attacker) {
        double dx = body.getX() - attacker.getX();
        double dz = body.getZ() - attacker.getZ();
        double length = Math.sqrt(dx * dx + dz * dz);
        if (length < 1.0E-4D) {
            dx = body.getRandom().nextDouble() - body.getRandom().nextDouble();
            dz = body.getRandom().nextDouble() - body.getRandom().nextDouble();
            length = Math.max(1.0E-4D, Math.sqrt(dx * dx + dz * dz));
        }
        body.push(dx / length * 0.45D, 0.12D, dz / length * 0.45D);
        body.hasImpulse = true;
    }
}
