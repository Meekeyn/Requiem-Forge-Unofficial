package ua.meekeyn.requiemunofficial.common.possession;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.NeutralMob;
import net.minecraft.world.entity.monster.Monster;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import ua.meekeyn.requiemunofficial.RequiemUnofficial;
import ua.meekeyn.requiemunofficial.common.init.ModGameRules;
import ua.meekeyn.requiemunofficial.common.util.ModTags;

import java.util.List;

@Mod.EventBusSubscriber(modid = RequiemUnofficial.MODID)
public final class PossessionDetectionManager {

    private static final double ALERT_RANGE = 50.0D;

    private PossessionDetectionManager() {
    }

    @SubscribeEvent
    public static void onLivingAttack(LivingAttackEvent event) {
        if (event.getEntity().level().isClientSide()) {
            return;
        }

        Entity attacker = event.getSource().getEntity();
        if (event.getEntity() instanceof Mob sensed && attacker instanceof Mob sensor) {
            attemptDetection(sensed, sensor, DetectionReason.ATTACKING);
            attemptDetection(sensor, sensed, DetectionReason.ATTACKED);
        }
    }

    public static void detectBumps(LivingEntity host) {
        List<Monster> touching = host.level().getEntitiesOfClass(
                Monster.class,
                host.getBoundingBox().inflate(0.15D),
                mob -> mob != host && mob.isAlive()
        );
        for (Monster sensor : touching) {
            attemptDetection(host, sensor, DetectionReason.BUMP);
        }
    }

    public static void attemptDetection(LivingEntity sensed, Mob sensor, DetectionReason reason) {
        if (!(sensor instanceof Monster)
                || sensor instanceof NeutralMob
                || PossessionManager.getPossessorId(sensed) == null) {
            return;
        }

        DetectionResult result = resultFor(
                ModGameRules.getPossessionDetection(sensed.level().getGameRules()),
                reason
        );
        if (result == DetectionResult.DETECTED) {
            PossessionManager.markDetectedByPossessedHost(sensed, sensor);
            sensor.setTarget(sensed);
        } else if (result == DetectionResult.CROWD_DETECTED) {
            if (sensed.getType().is(ModTags.UNDEAD)) {
                PossessionManager.markDetectedByPossessedHost(sensed, sensor);
                sensor.setTarget(sensed);
            } else {
                inciteCrowd(sensed, sensor);
            }
        }
    }

    public static DetectionResult resultFor(int mode, DetectionReason reason) {
        if (mode == ModGameRules.POSSESSION_DETECTION_DISABLED) {
            return DetectionResult.UNDETECTED;
        }
        if (reason == DetectionReason.ATTACKED
                || mode == ModGameRules.POSSESSION_DETECTION_HARD) {
            return DetectionResult.CROWD_DETECTED;
        }
        return DetectionResult.DETECTED;
    }

    private static void inciteCrowd(LivingEntity sensed, Mob sensor) {
        sensor.setTarget(sensed);
        for (Monster witness : sensed.level().getEntitiesOfClass(
                Monster.class,
                sensor.getBoundingBox().inflate(ALERT_RANGE),
                mob -> mob != sensor
                        && !(mob instanceof NeutralMob)
                        && mob.isAlive()
                        && mob.hasLineOfSight(sensed)
        )) {
            witness.setTarget(sensed);
        }
    }

    public enum DetectionReason {
        BUMP,
        ATTACKING,
        ATTACKED
    }

    public enum DetectionResult {
        UNDETECTED,
        DETECTED,
        CROWD_DETECTED
    }
}
