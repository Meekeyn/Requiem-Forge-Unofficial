package ua.meekeyn.requiemunofficial.client;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;
import ua.meekeyn.requiemunofficial.RequiemUnofficial;

public final class ClientVagrantTexture {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(RequiemUnofficial.MODID, "dynamic/vagrant_gray");
    private static boolean registered;

    private ClientVagrantTexture() {
    }

    public static ResourceLocation location() {
        if (!registered) {
            NativeImage image = new NativeImage(64, 64, false);
            image.fillRect(0, 0, 64, 64, 0xFFFFFFFF);
            Minecraft.getInstance().getTextureManager().register(TEXTURE, new DynamicTexture(image));
            registered = true;
        }
        return TEXTURE;
    }
}
