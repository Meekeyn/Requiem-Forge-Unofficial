package ua.meekeyn.requiemunofficial.client;

import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.animal.Bee;
import net.minecraft.world.entity.animal.Dolphin;
import net.minecraft.world.entity.animal.MushroomCow;
import net.minecraft.world.entity.animal.WaterAnimal;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import ua.meekeyn.requiemunofficial.RequiemUnofficial;
import ua.meekeyn.requiemunofficial.common.soul.ModCapabilities;
import ua.meekeyn.requiemunofficial.common.util.ModIds;
import ua.meekeyn.requiemunofficial.common.util.ModTags;

import java.util.UUID;

@Mod.EventBusSubscriber(modid = RequiemUnofficial.MODID, value = Dist.CLIENT)
public final class ClientPossessionVision {

    private static final ResourceLocation DICHROMATIC_SHADER = shader("dichromatic");
    private static final ResourceLocation TETRACHROMATIC_SHADER = shader("tetrachromatic");
    private static final ResourceLocation BEE_SHADER = shader("bee");
    private static final ResourceLocation DOLPHIN_SHADER = shader("dolphin");
    private static final ResourceLocation FISH_EYE_SHADER = shader("fish_eye");
    private static final ResourceLocation MOOSHROOM_SHADER = shader("mooshroom");
    private static final ResourceLocation SPECTRE_SHADER = shader("spectre");
    private static final ResourceLocation CREEPER_SHADER =
            new ResourceLocation("minecraft", "shaders/post/creeper.json");
    private static final ResourceLocation INVERT_SHADER =
            new ResourceLocation("minecraft", "shaders/post/invert.json");
    private static final ResourceLocation SPIDER_SHADER =
            new ResourceLocation("minecraft", "shaders/post/spider.json");
    private static final int MISSING_HOST_GRACE_TICKS = 10;

    private static ResourceLocation appliedShader;
    private static UUID lastPossessedHostId;
    private static ResourceLocation lastPossessedShader;
    private static int missingHostTicks;

    private ClientPossessionVision() {
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }

        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null || minecraft.level == null) {
            clearShader(minecraft);
            return;
        }

        UUID possessedHostId = minecraft.player.getCapability(ModCapabilities.PLAYER_SOUL)
                .resolve()
                .map(soul -> soul.getPossessedEntityId())
                .orElse(null);
        ResourceLocation shader = null;
        if (possessedHostId != null) {
            LivingEntity host = findClientHost(minecraft, possessedHostId);
            if (host != null) {
                shader = selectShader(host);
                lastPossessedHostId = possessedHostId;
                lastPossessedShader = shader;
                missingHostTicks = 0;
            } else if (possessedHostId.equals(lastPossessedHostId)
                    && missingHostTicks++ < MISSING_HOST_GRACE_TICKS) {
                shader = lastPossessedShader;
            }
        } else {
            lastPossessedHostId = null;
            lastPossessedShader = null;
            missingHostTicks = 0;
        }

        applyShader(minecraft, shader);
    }

    public static ResourceLocation selectShaderForTest(EntityType<?> type) {
        return selectShader(type, null);
    }

    private static ResourceLocation selectShader(LivingEntity entity) {
        return selectShader(entity.getType(), entity);
    }

    private static LivingEntity findClientHost(Minecraft minecraft, UUID hostId) {
        Entity camera = minecraft.getCameraEntity();
        if (camera instanceof LivingEntity living && hostId.equals(living.getUUID())) {
            return living;
        }
        if (minecraft.level == null) {
            return null;
        }
        for (Entity entity : minecraft.level.entitiesForRendering()) {
            if (entity instanceof LivingEntity living && hostId.equals(entity.getUUID())) {
                return living;
            }
        }
        return null;
    }

    private static ResourceLocation selectShader(EntityType<?> type, LivingEntity entity) {
        if (type == EntityType.CREEPER) {
            return CREEPER_SHADER;
        }
        if (type == EntityType.ENDERMAN) {
            return INVERT_SHADER;
        }
        if (type == EntityType.SPIDER || type == EntityType.CAVE_SPIDER) {
            return SPIDER_SHADER;
        }
        if (type.is(ModTags.DICHROMATS)) {
            return DICHROMATIC_SHADER;
        }
        if (type.is(ModTags.TETRACHROMATS)) {
            return TETRACHROMATIC_SHADER;
        }
        if (type.is(ModTags.HEMERALOPES) || type.is(ModTags.NIGHT_EYED)) {
            return SPECTRE_SHADER;
        }
        if (entity instanceof Bee || type == EntityType.BEE) {
            return BEE_SHADER;
        }
        if (entity instanceof MushroomCow || type == EntityType.MOOSHROOM) {
            return MOOSHROOM_SHADER;
        }
        if (entity instanceof Dolphin || type == EntityType.DOLPHIN) {
            return DOLPHIN_SHADER;
        }
        if (entity instanceof WaterAnimal || waterAnimalType(type)) {
            return FISH_EYE_SHADER;
        }
        return null;
    }

    private static boolean waterAnimalType(EntityType<?> type) {
        return type == EntityType.COD
                || type == EntityType.GLOW_SQUID
                || type == EntityType.PUFFERFISH
                || type == EntityType.SALMON
                || type == EntityType.SQUID
                || type == EntityType.TADPOLE
                || type == EntityType.TROPICAL_FISH
                || type == EntityType.TURTLE;
    }

    private static void applyShader(Minecraft minecraft, ResourceLocation shader) {
        if (shader == null) {
            clearShader(minecraft);
            return;
        }
        if (shader.equals(appliedShader)) {
            return;
        }
        clearShader(minecraft);
        minecraft.gameRenderer.loadEffect(shader);
        appliedShader = shader;
    }

    private static void clearShader(Minecraft minecraft) {
        if (appliedShader == null) {
            return;
        }
        minecraft.gameRenderer.shutdownEffect();
        appliedShader = null;
    }

    private static ResourceLocation shader(String name) {
        return ModIds.id("shaders/post/" + name + ".json");
    }
}
