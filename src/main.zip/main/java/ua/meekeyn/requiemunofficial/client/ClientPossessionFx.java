package ua.meekeyn.requiemunofficial.client;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Vector3f;
import ua.meekeyn.requiemunofficial.RequiemUnofficial;
import ua.meekeyn.requiemunofficial.common.network.PossessionFxPacket;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

@Mod.EventBusSubscriber(modid = RequiemUnofficial.MODID, value = Dist.CLIENT)
public final class ClientPossessionFx {

    private static final Map<ResourceLocation, Vector3f> TEXTURE_COLORS = new HashMap<>();
    private static final int POSSESSION_FX_TICKS = 40;
    private static final int POSSESSION_ATTEMPT_FX_TICKS = 8;

    private static int targetEntityId = -1;
    private static int ticksRemaining;

    private ClientPossessionFx() {
    }

    public static void handle(PossessionFxPacket packet) {
        if (packet.phase() == PossessionFxPacket.Phase.START) {
            targetEntityId = packet.targetEntityId();
            ticksRemaining = POSSESSION_ATTEMPT_FX_TICKS;
            return;
        }

        if (targetEntityId == packet.targetEntityId()) {
            ticksRemaining = POSSESSION_FX_TICKS;
        }
    }

    public static boolean isAnimatingForTest() {
        return ticksRemaining > 0;
    }

    public static int targetEntityIdForTest() {
        return targetEntityId;
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || ticksRemaining <= 0) {
            return;
        }

        spawnPossessionTextureParticles(7);
        ticksRemaining--;
        if (ticksRemaining <= 0) {
            targetEntityId = -1;
        }
    }

    private static void spawnPossessionTextureParticles(int count) {
        Minecraft minecraft = Minecraft.getInstance();
        ClientLevel level = minecraft.level;
        if (level == null || targetEntityId < 0) {
            return;
        }

        Entity target = level.getEntity(targetEntityId);
        if (target == null) {
            return;
        }

        DustParticleOptions particle = new DustParticleOptions(textureColor(minecraft, target), 1.15F);
        Vec3 center = target.position().add(0.0D, target.getBbHeight() * 0.55D, 0.0D);
        double radius = Math.max(0.2D, target.getBbWidth() * 0.55D);

        for (int i = 0; i < count; i++) {
            double x = target.getX() + (level.random.nextDouble() - 0.5D) * radius * 2.0D;
            double y = target.getY() + level.random.nextDouble() * target.getBbHeight();
            double z = target.getZ() + (level.random.nextDouble() - 0.5D) * radius * 2.0D;
            Vec3 velocity = center.subtract(x, y, z).normalize().scale(0.025D + level.random.nextDouble() * 0.03D);
            level.addParticle(particle, x, y, z, velocity.x, velocity.y, velocity.z);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static Vector3f textureColor(Minecraft minecraft, Entity target) {
        try {
            EntityRenderer renderer = minecraft.getEntityRenderDispatcher().getRenderer(target);
            ResourceLocation texture = renderer.getTextureLocation(target);
            return TEXTURE_COLORS.computeIfAbsent(texture, id -> loadAverageTextureColor(minecraft, id, target));
        } catch (RuntimeException exception) {
            return fallbackColor(target);
        }
    }

    private static Vector3f loadAverageTextureColor(Minecraft minecraft, ResourceLocation texture, Entity target) {
        try {
            var resource = minecraft.getResourceManager().getResource(texture);
            if (resource.isEmpty()) {
                return fallbackColor(target);
            }

            try (InputStream stream = resource.get().open();
                 NativeImage image = NativeImage.read(stream)) {
                long red = 0L;
                long green = 0L;
                long blue = 0L;
                long samples = 0L;
                int stepX = Math.max(1, image.getWidth() / 16);
                int stepY = Math.max(1, image.getHeight() / 16);

                for (int y = 0; y < image.getHeight(); y += stepY) {
                    for (int x = 0; x < image.getWidth(); x += stepX) {
                        int color = image.getPixelRGBA(x, y);
                        int alpha = color >>> 24;
                        if (alpha <= 24) {
                            continue;
                        }

                        red += color & 255;
                        green += color >> 8 & 255;
                        blue += color >> 16 & 255;
                        samples++;
                    }
                }

                if (samples > 0L) {
                    return new Vector3f(
                            Math.max(0.08F, red / (samples * 255.0F)),
                            Math.max(0.08F, green / (samples * 255.0F)),
                            Math.max(0.08F, blue / (samples * 255.0F))
                    );
                }
            }
        } catch (Exception exception) {
            return fallbackColor(target);
        }

        return fallbackColor(target);
    }

    private static Vector3f fallbackColor(Entity target) {
        int hash = target.getType().builtInRegistryHolder().key().location().toString().hashCode();
        float red = 0.35F + (hash & 63) / 128.0F;
        float green = 0.35F + (hash >> 6 & 63) / 128.0F;
        float blue = 0.35F + (hash >> 12 & 63) / 128.0F;
        return new Vector3f(Math.min(red, 0.9F), Math.min(green, 0.9F), Math.min(blue, 0.9F));
    }
}
