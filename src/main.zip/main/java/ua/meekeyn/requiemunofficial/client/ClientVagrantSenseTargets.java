package ua.meekeyn.requiemunofficial.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import ua.meekeyn.requiemunofficial.RequiemUnofficial;
import ua.meekeyn.requiemunofficial.common.network.VagrantSenseTargetsPacket;

import java.util.HashMap;
import java.util.Map;

@Mod.EventBusSubscriber(modid = RequiemUnofficial.MODID, value = Dist.CLIENT)
public final class ClientVagrantSenseTargets {
    private static final Map<Integer, Boolean> highlighted = new HashMap<>();
    private static int keepAliveTicks;

    private ClientVagrantSenseTargets() {
    }

    public static void handle(VagrantSenseTargetsPacket packet) {
        clearHighlights();
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) {
            return;
        }

        for (int entityId : packet.entityIds()) {
            Entity entity = level.getEntity(entityId);
            if (entity != null) {
                highlighted.put(entityId, entity.isCurrentlyGlowing());
                entity.setGlowingTag(true);
            }
        }
        keepAliveTicks = highlighted.isEmpty() ? 0 : 8;
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || highlighted.isEmpty()) {
            return;
        }

        if (Minecraft.getInstance().level == null || --keepAliveTicks <= 0) {
            clearHighlights();
        }
    }

    private static void clearHighlights() {
        ClientLevel level = Minecraft.getInstance().level;
        if (level != null) {
            for (Map.Entry<Integer, Boolean> entry : highlighted.entrySet()) {
                int entityId = entry.getKey();
                Entity entity = level.getEntity(entityId);
                if (entity != null) {
                    entity.setGlowingTag(entry.getValue());
                }
            }
        }
        highlighted.clear();
        keepAliveTicks = 0;
    }
}
