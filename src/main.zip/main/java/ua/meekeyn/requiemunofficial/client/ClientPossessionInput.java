package ua.meekeyn.requiemunofficial.client;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Spider;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import ua.meekeyn.requiemunofficial.RequiemUnofficial;
import ua.meekeyn.requiemunofficial.common.network.ModNetwork;
import ua.meekeyn.requiemunofficial.common.network.PossessionActionPacket;
import ua.meekeyn.requiemunofficial.common.network.PossessionInputPacket;
import ua.meekeyn.requiemunofficial.common.soul.SoulManager;
import ua.meekeyn.requiemunofficial.common.util.ModTags;

@Mod.EventBusSubscriber(modid = RequiemUnofficial.MODID, value = Dist.CLIENT)
public final class ClientPossessionInput {

    private static int jumpCooldown;
    private static int attackRepeatCooldown;

    private ClientPossessionInput() {
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }

        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null || minecraft.screen != null) {
            jumpCooldown = 0;
            attackRepeatCooldown = 0;
            return;
        }
        if (minecraft.player.isSpectator()) {
            jumpCooldown = 0;
            attackRepeatCooldown = 0;
            return;
        }

        while (ModKeyMappings.DISSOCIATION.consumeClick()) {
            ModNetwork.CHANNEL.sendToServer(
                    new PossessionActionPacket(PossessionActionPacket.Action.RELEASE)
            );
        }

        boolean controllingHost = minecraft.getCameraEntity() != minecraft.player
                || SoulManager.getPossessedEntityId(minecraft.player) != null;
        if (!controllingHost) {
            jumpCooldown = 0;
            attackRepeatCooldown = 0;
            return;
        }

        float yRot = minecraft.player.getYRot();
        float xRot = minecraft.player.getXRot();
        syncCameraHostRotation(minecraft, yRot, xRot);
        ModNetwork.CHANNEL.sendToServer(new PossessionInputPacket(
                movement(minecraft.options.keyUp.isDown(), minecraft.options.keyDown.isDown()),
                movement(minecraft.options.keyLeft.isDown(), minecraft.options.keyRight.isDown()),
                minecraft.options.keyJump.isDown(),
                minecraft.options.keyShift.isDown(),
                yRot,
                xRot
        ));

        while (minecraft.options.keyAttack.consumeClick()) {
            if (!isMiningBlock(minecraft)) {
                ModNetwork.CHANNEL.sendToServer(
                        new PossessionActionPacket(PossessionActionPacket.Action.ATTACK)
                );
                attackRepeatCooldown = 4;
            }
        }
        if (attackRepeatCooldown > 0) {
            attackRepeatCooldown--;
        }
        if (minecraft.options.keyAttack.isDown()
                && attackRepeatCooldown == 0
                && !isMiningBlock(minecraft)) {
            ModNetwork.CHANNEL.sendToServer(
                    new PossessionActionPacket(PossessionActionPacket.Action.ATTACK)
            );
            attackRepeatCooldown = 4;
        }

        while (ModKeyMappings.POSSESSION_INTERACT.consumeClick()) {
            ModNetwork.CHANNEL.sendToServer(
                    new PossessionActionPacket(PossessionActionPacket.Action.INTERACT)
            );
        }

        if (jumpCooldown > 0) {
            jumpCooldown--;
        }
        if (minecraft.options.keyJump.isDown() && jumpCooldown == 0) {
            ModNetwork.CHANNEL.sendToServer(
                    new PossessionActionPacket(PossessionActionPacket.Action.JUMP)
            );
            jumpCooldown = 8;
        }
    }

    private static float movement(boolean positive, boolean negative) {
        if (positive == negative) {
            return 0.0F;
        }
        return positive ? 1.0F : -1.0F;
    }

    private static void syncCameraHostRotation(Minecraft minecraft, float yRot, float xRot) {
        if (!(minecraft.getCameraEntity() instanceof LivingEntity host)
                || minecraft.getCameraEntity() == minecraft.player) {
            return;
        }
        host.setYRot(yRot);
        host.setYHeadRot(yRot);
        host.yBodyRot = yRot;
        host.yRotO = yRot;
        host.yHeadRotO = yRot;
        host.yBodyRotO = yRot;
        host.setXRot(xRot);
        host.xRotO = xRot;
    }

    @SubscribeEvent
    public static void onInteractionKey(InputEvent.InteractionKeyMappingTriggered event) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null
                || minecraft.player.isSpectator()
                || !isControllingPossessedHost(minecraft)) {
            return;
        }
        if (shouldAllowSkeletonSpiderMount(minecraft)) {
            return;
        }
        if (!event.isAttack()
                || minecraft.hitResult != null
                && minecraft.hitResult.getType() == HitResult.Type.BLOCK) {
            return;
        }

        event.setCanceled(true);
        event.setSwingHand(false);
    }

    private static boolean shouldAllowSkeletonSpiderMount(Minecraft minecraft) {
        if (!(minecraft.getCameraEntity() instanceof LivingEntity host)
                || !host.getType().is(ModTags.HUMANOID_SKELETONS)
                || host.isPassenger()
                || minecraft.hitResult == null
                || minecraft.hitResult.getType() != HitResult.Type.ENTITY
                || !(((EntityHitResult) minecraft.hitResult).getEntity() instanceof Spider spider)) {
            return false;
        }
        return spider.getPassengers().isEmpty();
    }

    private static boolean isMiningBlock(Minecraft minecraft) {
        return minecraft.hitResult != null
                && minecraft.hitResult.getType() == HitResult.Type.BLOCK;
    }

    private static boolean isControllingPossessedHost(Minecraft minecraft) {
        return minecraft.getCameraEntity() != minecraft.player
                || SoulManager.getPossessedEntityId(minecraft.player) != null;
    }
}
